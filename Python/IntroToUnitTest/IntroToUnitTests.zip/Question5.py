# -*- coding: utf-8 -*-
"""
Created on Sun Jun 11 23:12:15 2017

@author: 582139
"""

def countDigits(line):
    count = 0
    for c in line:
        count += c.isdigit()
    return count

def main():
    p = input('Enter a path/name for a file with text that might include numbers: ')
    f = open(p, "r")
    print()
    line_num = 1
    for line in f.readlines():
        print('There are', countDigits(line), 'digits in line', line_num)
        line_num += 1
    # I should really close the file here!       

if __name__ == '__main__':
    main()