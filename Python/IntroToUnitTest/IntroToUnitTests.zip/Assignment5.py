# -*- coding: utf-8 -*-
"""
Created on Sun Jun 11 20:16:55 2017

@author: 582139
"""

def sumList(nums):
    result = 0
    for num in nums:
        result += num
    return result

def squareEach(nums):
    for i in range(len(nums)):
        nums[i] = nums[i]**2
        
def toNumbers(strList):
    for i in range(len(strList)):
        strList[i] = eval(strList[i])
        
def convert_to_number_list(s):
    nums = s.split()
    toNumbers(nums)
    return nums

