# -*- coding: utf-8 -*-
"""
Created on Sun Jun 11 20:22:07 2017

@author: 582139
"""

import unittest
import Assignment5 as a5
import Question5 as q5

class test_assignment5(unittest.TestCase):

    def setUp(self):
        pass
    
    def test_sumList(self):
        args_map = [([1,2,3], 6), 
                    ([-1.2, 1.2, 2.0], 2.0), 
                    ([-2,2,3.4], 3.4)]
        for args in args_map:
            self.assertEqual(a5.sumList(args[0]), args[1], "failed on args {}".format(args))
            
    def test_squareEach(self):
        args_map = [([0.5,1,2], [0.25,1,4]), ([-2,0,2.5,100], [4,0,6.25,10000])]
        for args in args_map:
            a5.squareEach(args[0])
            self.assertListEqual(args[0], args[1])
            
    def test_convert_to_number_list(self):
        args_map = [('1 3 5 -4 7 -11', [1,3,5,-4,7,-11]), ('', [])]
        for args in args_map:
            self.assertListEqual(a5.convert_to_number_list(args[0]), args[1])
            
    def test_toNumbers(self):
        args_map = [(['1','0','-2','25'], [1, 0, -2, 25]), ([], [])]
        for args in args_map:
            a5.toNumbers(args[0])
            self.assertListEqual(args[0], args[1]) 
            
    def test_countDigits(self):
        args_map = [("213 Goldfinch Ln, Summerville", 3), ('', 0), ("!@$!@#%^4567890 BVNKROFU", 7)]
        for args in args_map:
            self.assertEqual(q5.countDigits(args[0]), args[1], "failed on args {}".format(args))
        

if __name__ == '__main__':
    unittest.main()

